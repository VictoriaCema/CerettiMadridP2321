
package persistence;

public class Persistencia {
    
}
