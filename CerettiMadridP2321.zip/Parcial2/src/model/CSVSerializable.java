package model;


interface CSVSerializable<T> {
    
    String toCSV();
    
}
