package model;

import java.io.Serializable;

public class ViajeTemporal implements CSVSerializable, Comparable<ViajeTemporal>, Serializable{
    private  final int id;
    private  final String descripcion;
    private  final String viajero;
    private  final DestinoTemporal destino;

    public ViajeTemporal(int id, String descripcion, String viajero, DestinoTemporal destino) {
        this.id = id;
        this.descripcion = descripcion;
        this.viajero = viajero;
        this.destino = destino;
    }

    public int getId() {
        return id;
    }

    public DestinoTemporal getDestino() {
        return destino;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getViajero() {
        return viajero;
    }
    
    
    
    static ViajeTemporal fromCSV(String viajeTemporalCSV){
        viajeTemporalCSV = viajeTemporalCSV.substring(0, viajeTemporalCSV.length());
        String[] datos = viajeTemporalCSV.split(",");  //Esto devuelve un array de String (String[]) y corta en cada coma
        return new ViajeTemporal( Integer.parseInt(datos[0]), datos[1], datos[2], DestinoTemporal.valueOf(datos[3]));
    }

    @Override
    public String toCSV() {
        return id + "," + descripcion + "," + viajero + "," + destino;
    }
    
    static String toHeaderCSV(){
        return "id,descripcion,viajero,destino\n";
    }

    @Override
    public int compareTo(ViajeTemporal o) {
        return Integer.compare(this.id, o.id);
    }

    
}
