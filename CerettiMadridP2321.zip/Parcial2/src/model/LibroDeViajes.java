package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class LibroDeViajes<T>{
    
    private List<T> viajes = new ArrayList<T>();
    
  
    public void agregar(T item) {
        Objects.requireNonNull(item, "Elemento nullo");
        viajes.add(item);
    }

    public boolean eliminar(T item) {
        return viajes.remove(item);
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return viajes.get(indice);
    }
    private void validarIndice(int indice){
        if (indice < 0 || indice >= viajes.size()){
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();
        for(T viaje: viajes){
            if (criterio.test(viaje)){
                resultado.add(viaje);
            }
        }return resultado;
    }
    
    public Iterator<T> iterator() {
        List<T> copia = new ArrayList<>(viajes);  
        if (!viajes.isEmpty() && viajes.getFirst() instanceof Comparable){
            ((List<Comparable>) copia).sort(Comparator.naturalOrder());
        }                  
        return copia.iterator() ;
    }    
 
    public Iterator<T> iterator(Comparator<? super T> cmp) {
        List<T> copia = new ArrayList<>(viajes);
        if (!viajes.isEmpty()&& viajes.getFirst() instanceof Comparable){
            copia.sort(cmp); 
        }     
        return copia.iterator();
    }

    public void guardarEnCSV(String path){
        
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(path))){
            escritor.write(ViajeTemporal.toHeaderCSV());
            for(T v: viajes){                
                escritor.write(((ViajeTemporal)v).toCSV() + "\n");                
            }
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }            
    }
    
    public void cargarDesdeCSV(String path, Function<String, T> accion){
        
        viajes.clear();
        try(BufferedReader lector = new BufferedReader(new FileReader(path))){ //a FileReader le paso el path o el File
            lector.readLine();
            String linea;
            while ((linea = lector.readLine()) != null){                
                viajes.add(accion.apply(linea));                 
            }        
        }catch (IOException ex) {
            System.out.println(ex.getMessage());
            }
    }
    
    public void guardarEnArchivo(String path){
        try(ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))){            
            serializador.writeObject(viajes);           
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public List<ViajeTemporal> cargarDesdeArchivo(String path)
        throws IOException, ClassNotFoundException {

    try (ObjectInputStream deser = new ObjectInputStream(new FileInputStream(path))) {
        return (List<ViajeTemporal>) deser.readObject();
    }
}

    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for(T v: viajes){
            accion.accept(v);
        }
    }
    
    public void ordenar(Comparator<? super T> cmp) {
    viajes.sort(cmp);
    }
    
}
